package edu.arizona.cs;

import org.apache.lucene.analysis.standard.StandardAnalyzer;

/**
 * Skeleton for HW3
 *
 */
public class App
{
    public static void main( String[] args )
    {
        // this is just to make sure that the Lucene dependency works
        StandardAnalyzer analyzer = new StandardAnalyzer();

        // replace this with the actual homework :)
        System.out.println( "Hello Homework 3!" );
    }
}
