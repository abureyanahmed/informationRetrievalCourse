package brain
import scala.collection.mutable.{ListBuffer, Map}

/**
  * Created by mithunpaul on 2/17/17.
  */
object dataStructures {

//  case class documentIDPositions (var docId:Int, var positions: ListBuffer[Int]);
//  case class templateCount(templateId: Int, count: Int)
//  var seqOfSeedAntonymTemplates = new ListBuffer[SeedTemplateForAntonyms]()

  ();



}
