Just type sbt run

and follow the prompts


will be submitting only code for Qn 5 and 4 online. Will be slipping in hard copy into mihai's room.

Please grade code along with hard copy. Details are mentioned in teh hard copy.


will work for queries with words separated by spaces
Eg: "information retrieval"
"dog labrador"
